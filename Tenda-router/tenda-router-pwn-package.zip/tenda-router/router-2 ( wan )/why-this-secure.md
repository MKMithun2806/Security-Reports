### Security Assessment Log: Tenda Network Audit

**Target 1: 192.168.8.145 (Vulnerable)**
- **Recon:** `nuclei -tags iot,router,hardware`
- **Finding:** `tenda-credential-disclosure` via `/cgi-bin/DownloadCfg/RouterCfm.jpg`
- **Result:** Successfully downloaded `RouterCfm.cfg` and extracted administrative credentials.

**Target 2: 192.168.8.1 (Hardened)**
- **Recon:** Probed `/goform/` endpoints; received 302 Redirects to `/login.html`.
- **Vulnerability Scan:** Ran `nmap --script=http-vuln*`. Received false positive for `CVE-2010-0738` (JMX-console).
- **JS Analysis:** Downloaded `login.js`. Confirmed password is Base64 encoded; identified requirement for dynamic timestamp parameter.
- **Authentication Bypass Attempt:**
    - Test 1: `curl` POST with plaintext credentials (401 Unauthorized).
    - Test 2: `curl` POST with Base64 credentials and generated timestamp (401 Unauthorized).
    - Test 3: `curl` session priming with `cookies.txt` + Base64 credentials (401 Unauthorized).
- **Result:** Authentication failure due to server-side CSRF token/challenge-response requirement.

**Summary Conclusion:**
- Device `.145` is susceptible to direct configuration file theft (critical flaw).
- Device `.8.1` is hardened against simple path-traversal and automated authentication bypass; requires a full browser-based JS handshake (or proxy injection) to gain access.
