1. Administrative Web Interface Credentials
Username: admin
Encoded Password: YWRtaW5saW1yYXM=
Which is Base64 for "adminlimras"

2. Wireless Network (Wi-Fi) Security Keys
SSID 1: Zacs Valley 1013
WPA Pre-Shared Key: zacs@2024
SSID 2: Zacs Valley 1014
WPA Pre-Shared Key: zacs@2024
SSID 3 (Secondary Interface): wl0.2_ssid=Zacs Valley 1014
WPA Pre-Shared Key: zacs@2024
Extended Pass field: zacs@2024

3. Hardware Authentication PIN
WPS Device PIN: 59409892